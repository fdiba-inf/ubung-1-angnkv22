package exercise1;

public class HelloFdiba {

  public static void main(String[] args) {
    System.out.println("Hello FDIBA!");
  }

}
