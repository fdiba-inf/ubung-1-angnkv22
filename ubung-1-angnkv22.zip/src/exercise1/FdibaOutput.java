package exercise1;
public class FdibaOutput {
public static void main(String [] args){
    System.out.println("FFFFF DDDDD   II BBBBB      A");
    System.out.println("F     D    D  II B    B    A A");
    System.out.println("FFFF  D     D II BBBBB    AAAAA");
    System.out.println("F     D    D  II B    B  A     A");
    System.out.println("F     DDDDD   II BBBBB  A       A");
  }
}